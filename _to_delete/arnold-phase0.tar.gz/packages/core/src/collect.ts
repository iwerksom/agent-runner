/**
 * Purpose: preserve what a run produced after its worktree is handed back, and
 * turn the agent's declared result into a row that can be charted.
 *
 * Two jobs, one lifetime: artifacts (files worth keeping) and outcome (the
 * structured verdict). Both run after the SDK loop finishes and before the
 * workspace is released, because the worktree is reset on the next lease.
 *
 * Outcome parsing never throws. A malformed result is recorded as
 * outcome "unparsed" with the raw text in the payload, because a run whose
 * verdict cannot be read is a fact the operator needs to see, and a thrown error
 * here would turn a completed run into a failed one and lose the transcript.
 */

import { copyFile, mkdir, readFile, stat } from "node:fs/promises";
import path from "node:path";
import type { Artifact, RunOutcome } from "@prisma/client";
import fastGlob from "fast-glob";
import type { OutcomeSpec } from "./agents.js";
import { prisma } from "./db.js";
import { stringifyJsonColumn } from "./json.js";

/** Anything bigger is skipped: the artifact store is for reports, not builds. */
const MAX_ARTIFACT_BYTES = 5 * 1024 * 1024;

/** Absolute artifact root. Relative env values resolve against the cwd. */
export function artifactRoot(): string {
	const configured = process.env.ARNOLD_ARTIFACT_ROOT;
	return path.resolve(
		configured !== undefined && configured !== "" ? configured : "./.arnold/artifacts",
	);
}

/** Inferred from the path, because the producing agent does not label its files. */
function artifactKindFor(relativePath: string): string {
	const posixPath = relativePath.split(path.sep).join("/");
	if (posixPath.includes(".pr-loop/reports")) return "report";
	if (posixPath.includes(".week-plan/orders")) return "work-order";
	if (posixPath.includes(".week-plan/parked")) return "parked";
	if (posixPath.endsWith(".jsonl")) return "log";
	return "other";
}

const MIME_BY_EXTENSION: Record<string, string> = {
	".md": "text/markdown",
	".markdown": "text/markdown",
	".txt": "text/plain",
	".json": "application/json",
	".jsonl": "application/x-ndjson",
	".ndjson": "application/x-ndjson",
	".csv": "text/csv",
	".tsv": "text/tab-separated-values",
	".html": "text/html",
	".svg": "image/svg+xml",
	".png": "image/png",
	".jpg": "image/jpeg",
	".jpeg": "image/jpeg",
	".log": "text/plain",
	".patch": "text/x-diff",
	".diff": "text/x-diff",
	".yml": "text/yaml",
	".yaml": "text/yaml",
};

function mimeTypeFor(relativePath: string): string {
	return (
		MIME_BY_EXTENSION[path.extname(relativePath).toLowerCase()] ?? "application/octet-stream"
	);
}

/**
 * Copy every match of `globs` out of the worktree into the artifact store and
 * record a row per file. Returns the rows, so the caller can show them without a
 * second query.
 */
export async function collectArtifacts(
	runId: string,
	workspacePath: string,
	globs: string[],
): Promise<Artifact[]> {
	if (globs.length === 0) return [];

	const matches = await fastGlob(globs, {
		cwd: workspacePath,
		onlyFiles: true,
		dot: true, // every artifact directory in diamond_frontend is dot-prefixed
		followSymbolicLinks: false,
		unique: true,
	});
	if (matches.length === 0) return [];

	const destinationDirectory = path.join(artifactRoot(), runId);
	await mkdir(destinationDirectory, { recursive: true });

	const rows: Artifact[] = [];
	const usedFileNames = new Set<string>();

	for (const relativePath of matches.sort()) {
		const absoluteSource = path.join(workspacePath, relativePath);
		let sizeBytes: number;
		try {
			sizeBytes = (await stat(absoluteSource)).size;
		} catch (caught: unknown) {
			console.warn(
				`[arnold] artifact ${relativePath} disappeared before collection: ${String(caught)}`,
			);
			continue;
		}
		if (sizeBytes > MAX_ARTIFACT_BYTES) {
			console.warn(
				`[arnold] skipped artifact ${relativePath} for run ${runId}: ${sizeBytes} bytes exceeds the ${MAX_ARTIFACT_BYTES} byte limit`,
			);
			continue;
		}

		// Two globs can match the same basename in different directories, and the
		// store is flat per run, so collisions get a numeric prefix instead of
		// silently overwriting the earlier file.
		let fileName = path.basename(relativePath);
		if (usedFileNames.has(fileName)) {
			fileName = `${usedFileNames.size + 1}-${fileName}`;
		}
		usedFileNames.add(fileName);

		await copyFile(absoluteSource, path.join(destinationDirectory, fileName));

		rows.push(
			await prisma.artifact.create({
				data: {
					runId,
					kind: artifactKindFor(relativePath),
					path: relativePath.split(path.sep).join("/"),
					// A key, not an absolute path: Phase 1 swaps the root for a
					// bucket and the key stays valid.
					storageKey: `${runId}/${fileName}`,
					mimeType: mimeTypeFor(relativePath),
					sizeBytes,
				},
			}),
		);
	}

	return rows;
}

/** Read a collected artifact back out of the store. */
export async function readArtifact(storageKey: string): Promise<Buffer> {
	return readFile(path.resolve(artifactRoot(), storageKey));
}

function toRecord(value: unknown): Record<string, unknown> | undefined {
	return typeof value === "object" && value !== null && !Array.isArray(value)
		? (value as Record<string, unknown>)
		: undefined;
}

function stringField(record: Record<string, unknown> | undefined, key: string): string | undefined {
	if (record === undefined) return undefined;
	const value = record[key];
	if (typeof value === "string" && value !== "") return value;
	if (typeof value === "number" || typeof value === "boolean") return String(value);
	return undefined;
}

async function createOutcomeRow(
	runId: string,
	outcome: string,
	reasonCode: string | undefined,
	payload: unknown,
): Promise<RunOutcome> {
	return prisma.runOutcome.create({
		data: {
			runId,
			outcome,
			reasonCode: reasonCode ?? null,
			payload: stringifyJsonColumn(payload),
		},
	});
}

/** Last fenced ```json block, which is the one the agent settled on. */
function lastJsonBlock(text: string): string | undefined {
	const fence = /```json\s*\r?\n([\s\S]*?)```/g;
	let last: string | undefined;
	for (;;) {
		const match = fence.exec(text);
		if (match === null) break;
		if (match[1] !== undefined) last = match[1];
	}
	return last;
}

/**
 * A verdict of `hot-files: some-branch` carries both the outcome and its reason,
 * so it splits on the first colon.
 */
function splitVerdict(raw: string): { verdictOutcome: string; verdictReasonCode?: string } {
	const separator = raw.indexOf(":");
	if (separator < 0) return { verdictOutcome: raw.trim() };
	const outcome = raw.slice(0, separator).trim();
	const reason = raw.slice(separator + 1).trim();
	return reason === ""
		? { verdictOutcome: outcome }
		: { verdictOutcome: outcome, verdictReasonCode: reason };
}

async function newestMatchingFile(
	workspacePath: string,
	pathGlob: string,
): Promise<string | undefined> {
	const matches = await fastGlob([pathGlob], {
		cwd: workspacePath,
		onlyFiles: true,
		dot: true,
		followSymbolicLinks: false,
	});
	let newestPath: string | undefined;
	let newestMtimeMs = -1;
	for (const relativePath of matches) {
		try {
			const stats = await stat(path.join(workspacePath, relativePath));
			if (stats.mtimeMs > newestMtimeMs) {
				newestMtimeMs = stats.mtimeMs;
				newestPath = relativePath;
			}
		} catch {
			// Raced with a cleanup; the other matches are still usable.
		}
	}
	return newestPath;
}

/**
 * Read the run's declared result and record it. Returns every row created, which
 * is one row today, so a future fan-out agent can emit several without changing
 * the signature.
 */
export async function parseOutcome(
	runId: string,
	workspacePath: string,
	spec: OutcomeSpec | undefined,
	finalMessageText: string,
): Promise<RunOutcome[]> {
	if (spec === undefined) return [];

	try {
		if (spec.kind === "json-block") {
			const block = lastJsonBlock(finalMessageText);
			if (block === undefined) {
				return [
					await createOutcomeRow(runId, "unparsed", "no-json-block", {
						rawText: finalMessageText,
					}),
				];
			}
			const parsed: unknown = JSON.parse(block);
			const record = toRecord(parsed);
			const outcome = stringField(record, "outcome") ?? "ok";
			const reasonCode =
				stringField(record, "reasonCode") ??
				stringField(record, "reason_code") ??
				stringField(record, "reason");
			return [await createOutcomeRow(runId, outcome, reasonCode, parsed)];
		}

		if (spec.kind === "jsonl") {
			const absolutePath = path.join(workspacePath, spec.path);
			const raw = await readFile(absolutePath, "utf8");
			const lines = raw
				.split(/\r?\n/)
				.map((line) => line.trim())
				.filter((line) => line !== "");
			const lastLine = lines[lines.length - 1];
			if (lastLine === undefined) {
				return [
					await createOutcomeRow(runId, "unparsed", "empty-jsonl", {
						rawText: "",
						sourcePath: spec.path,
					}),
				];
			}
			const parsed: unknown = JSON.parse(lastLine);
			const record = toRecord(parsed);
			const outcome = stringField(record, spec.outcomeKey) ?? "unparsed";
			const reasonCode =
				spec.reasonKey === undefined ? undefined : stringField(record, spec.reasonKey);
			return [
				await createOutcomeRow(runId, outcome, reasonCode, {
					record: parsed,
					sourcePath: spec.path,
				}),
			];
		}

		// kind === "report": the verdict is a line, either in a file or in the
		// final message when the agent writes no file at all.
		let verdictSourceText = finalMessageText;
		let verdictSourcePath: string | undefined;
		if (spec.pathGlob !== "") {
			verdictSourcePath = await newestMatchingFile(workspacePath, spec.pathGlob);
			if (verdictSourcePath !== undefined) {
				verdictSourceText = await readFile(
					path.join(workspacePath, verdictSourcePath),
					"utf8",
				);
			}
		}
		// Multiline: the manifests anchor with ^ against a line, not the document.
		const verdictMatch = new RegExp(spec.verdictPattern, "m").exec(verdictSourceText);
		if (verdictMatch === null) {
			// Some agents only announce the negative case. work-order-scoper prints
			// "REJECT: <code>" when it refuses and otherwise just returns the work
			// order, so no match on a successful run is the accepted path, not a
			// parse failure. Only a manifest that declares a fallback gets that
			// reading; without one, a non-match stays "unparsed" and looks wrong.
			if (spec.fallbackOutcome !== undefined) {
				return [
					await createOutcomeRow(runId, spec.fallbackOutcome, undefined, {
						verdictPattern: spec.verdictPattern,
						sourcePath: verdictSourcePath,
						note: "verdict pattern did not match; recorded the manifest fallbackOutcome",
					}),
				];
			}
			return [
				await createOutcomeRow(runId, "unparsed", "no-verdict-match", {
					rawText: verdictSourceText,
					verdictPattern: spec.verdictPattern,
					sourcePath: verdictSourcePath,
				}),
			];
		}
		const raw = verdictMatch[1] ?? verdictMatch[0];
		const { verdictOutcome, verdictReasonCode } = splitVerdict(raw);
		return [
			await createOutcomeRow(runId, verdictOutcome, verdictReasonCode, {
				verdictRaw: raw,
				matchedText: verdictMatch[0],
				sourcePath: verdictSourcePath,
			}),
		];
	} catch (caught: unknown) {
		return [
			await createOutcomeRow(runId, "unparsed", "parse-error", {
				rawText: finalMessageText,
				parseError: String(caught),
				outcomeSpec: spec,
			}),
		];
	}
}
