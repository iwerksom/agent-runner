/**
 * Purpose: the manifest set for the `diamond-frontend` repo, as a static array.
 *
 * Hand-maintained on purpose. A dynamic fs scan of this directory cannot be
 * bundled by Next, and a registry that only resolves at runtime cannot be
 * type-checked at build time either. Adding an agent means adding a line here,
 * which is a fair price for both.
 *
 * The type import is `import type` so this module has no runtime dependency on
 * @arnold/core, which would otherwise close a require cycle with
 * packages/core/src/registry.ts.
 */

import type { AgentManifest } from "@arnold/core";
import { manifest as prLoopAnalyzerManifest } from "./pr-loop-analyzer.js";
import { manifest as workOrderScoperManifest } from "./work-order-scoper.js";

/** Order is display order in the console. Read-only agents first. */
export const diamondFrontendManifests: AgentManifest[] = [
	workOrderScoperManifest,
	prLoopAnalyzerManifest,
];
