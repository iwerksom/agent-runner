/**
 * Purpose: smoke-test the two modules that have no database dependency, against
 * the REAL prompt files in the diamond_frontend checkout. These are the parts
 * most likely to be silently wrong: a prompt whose `<PR>` token never got
 * substituted still runs, it just analyses the wrong PR, and a tool policy that
 * fails open looks identical to one that works until an agent writes something.
 *
 * Run: npx tsx scripts/smoke.ts <path-to-diamond_frontend-checkout>
 * Exits non-zero on the first failed assertion.
 */

import { renderPrompt, validateArgs } from "../packages/core/src/prompt.js";
import { buildCanUseTool } from "../packages/core/src/writeScope.js";
import { manifest as analyzer } from "../registry/diamond-frontend/pr-loop-analyzer.js";
import { manifest as scoper } from "../registry/diamond-frontend/work-order-scoper.js";

const checkout = process.argv[2];
if (checkout === undefined) {
	console.error("usage: tsx scripts/smoke.ts <path-to-diamond_frontend-checkout>");
	process.exit(2);
}

let failures = 0;
function check(label: string, condition: boolean, detail?: string): void {
	if (condition) {
		console.log(`  ok    ${label}`);
	} else {
		failures += 1;
		console.log(`  FAIL  ${label}${detail === undefined ? "" : `\n        ${detail}`}`);
	}
}

console.log("\n[1] prompt rendering: pr-loop-analyzer uses the literal token <PR>, not $1");
{
	const resolved = validateArgs(analyzer, { prNumber: "1234" });
	check("validateArgs resolves prNumber", resolved.prNumber === "1234");

	const rendered = await renderPrompt(analyzer, { prNumber: "1234" }, checkout);
	const body = rendered.promptBody;
	check("prompt body is non-trivial", body.length > 500, `length ${body.length}`);
	check("no <PR> token survives substitution", !body.includes("<PR>"));
	check("the PR number is present", body.includes("1234"));
	check("frontmatter was stripped", !body.trimStart().startsWith("---"));
}

console.log("\n[2] prompt rendering: work-order-scoper gets a rebuilt context block");
{
	const rendered = await renderPrompt(
		scoper,
		{
			woNumber: "3",
			ticketKey: "DAP-999",
			issueText: "Rename the thing. Acceptance: the thing is renamed.",
			windowMinutes: "75",
			hotFiles: "src/app/foo.tsx",
		},
		checkout,
	);
	const body = rendered.promptBody;
	check("context template was appended", body.includes("## Your assignment"));
	check("woNumber substituted", body.includes("WO-3"));
	check("ticketKey substituted", body.includes("DAP-999"));
	check("windowMinutes substituted", body.includes("75"));
	check("issueText substituted", body.includes("the thing is renamed"));
	check("no unfilled {{placeholders}} remain", !/\{\{\w+\}\}/.test(body));
	check(
		"declaredTools was read from the subagent frontmatter",
		(rendered.declaredTools ?? []).includes("Read"),
		`got ${JSON.stringify(rendered.declaredTools)}`,
	);
}

console.log("\n[3] prompt rendering: a missing required argument is refused");
{
	let threw = false;
	try {
		await renderPrompt(analyzer, {}, checkout);
	} catch {
		threw = true;
	}
	check("missing prNumber throws instead of rendering a broken prompt", threw);
}

console.log("\n[4] write scope: read-only work-order-scoper cannot write");
{
	const canUse = buildCanUseTool({
		manifest: scoper,
		workspacePath: checkout,
		declaredTools: ["Read", "Grep", "Glob", "Bash"],
	});
	const write = await canUse("Write", { file_path: `${checkout}/src/app/x.tsx`, content: "x" });
	check("Write denied", write.behavior === "deny");
	const edit = await canUse("Edit", { file_path: `${checkout}/README.md` });
	check("Edit denied", edit.behavior === "deny");
	const read = await canUse("Read", { file_path: `${checkout}/README.md` });
	check("Read allowed", read.behavior === "allow");
	const gitLog = await canUse("Bash", { command: "git log --oneline -5" });
	check("Bash(git log) allowed", gitLog.behavior === "allow");
	const gitPush = await canUse("Bash", { command: "git push origin HEAD" });
	check("Bash(git push) denied", gitPush.behavior === "deny");
	const chained = await canUse("Bash", { command: "git log --oneline && rm -rf src" });
	check("a chained command is not smuggled past the allow-list", chained.behavior === "deny");
}

console.log("\n[5] write scope: artifacts-scoped pr-loop-analyzer writes only its report");
{
	const canUse = buildCanUseTool({ manifest: analyzer, workspacePath: checkout });
	const report = await canUse("Write", {
		file_path: `${checkout}/.pr-loop/reports/PR-1234-analyzer.md`,
		content: "x",
	});
	check("Write inside .pr-loop/reports allowed", report.behavior === "allow");
	const source = await canUse("Write", {
		file_path: `${checkout}/src/app/page.tsx`,
		content: "x",
	});
	check("Write into src denied", source.behavior === "deny");
	const claudeDir = await canUse("Write", {
		file_path: `${checkout}/.claude/commands/pr-loop-analyzer.md`,
		content: "x",
	});
	check("Write into .claude denied by the global rule", claudeDir.behavior === "deny");
	const env = await canUse("Write", { file_path: `${checkout}/.env.local`, content: "x" });
	check("Write into .env.local denied by the global rule", env.behavior === "deny");
	const escape = await canUse("Write", { file_path: "/etc/passwd", content: "x" });
	check("Write outside the workspace denied", escape.behavior === "deny");
	const traversal = await canUse("Write", {
		file_path: `${checkout}/.pr-loop/reports/../../../../etc/passwd`,
		content: "x",
	});
	check("path traversal denied", traversal.behavior === "deny");
}

console.log(
	failures === 0 ? "\nAll smoke checks passed.\n" : `\n${failures} smoke check(s) failed.\n`,
);
process.exit(failures === 0 ? 0 : 1);
