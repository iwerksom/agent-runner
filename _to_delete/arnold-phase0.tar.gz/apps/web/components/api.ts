/**
 * Purpose: server-side readers for the fixed Arnold HTTP contract. Pages are
 * server components, so they call these; nothing here runs in the browser
 * (`headers()` is server-only). Every read is `no-store`: a console whose run
 * list is a cached snapshot is worse than one that is a second slower.
 *
 * Reads degrade instead of throwing. A route that is not up yet returns an
 * empty collection so the surrounding page still renders its shell and its
 * empty state, which is what an operator needs in order to see *that* the tier
 * is down.
 */

import { headers } from "next/headers";
import type { AgentSummary, RepoDto, RunDetail, RunStatus, RunSummary } from "@/components/types";

/** Absolute origin for server-side fetches; relative URLs are not resolvable there. */
async function apiOrigin(): Promise<string> {
	const configured = process.env.ARNOLD_PUBLIC_ORIGIN;
	if (configured) return configured.replace(/\/$/, "");

	const headerList = await headers();
	const host = headerList.get("x-forwarded-host") ?? headerList.get("host") ?? "localhost:3000";
	const proto =
		headerList.get("x-forwarded-proto") ??
		(host.startsWith("localhost") || host.startsWith("127.0.0.1") ? "http" : "https");
	return `${proto}://${host}`;
}

async function getJson<T>(path: string): Promise<T | undefined> {
	try {
		const response = await fetch(`${await apiOrigin()}${path}`, {
			cache: "no-store",
			headers: { accept: "application/json" },
		});
		if (!response.ok) return undefined;
		return (await response.json()) as T;
	} catch {
		// Swallowed on purpose: the caller renders an empty state, and a 500 page
		// would hide every other panel on the screen.
		return undefined;
	}
}

export async function fetchRepos(): Promise<RepoDto[]> {
	const body = await getJson<{ repos: RepoDto[] }>("/api/repos");
	return body?.repos ?? [];
}

export async function fetchAgents(repoSlug?: string): Promise<AgentSummary[]> {
	const query = repoSlug ? `?repo=${encodeURIComponent(repoSlug)}` : "";
	const body = await getJson<{ agents: AgentSummary[] }>(`/api/agents${query}`);
	return body?.agents ?? [];
}

export async function fetchAgent(agentId: string): Promise<AgentSummary | undefined> {
	// There is no /api/agents/[id] in the contract, so the detail page filters the
	// list. Cheap in Phase 0 (tens of agents) and keeps the contract untouched.
	const agents = await fetchAgents();
	return agents.find((agent) => agent.id === agentId);
}

export type RunQuery = {
	agentId?: string;
	repoSlug?: string;
	status?: RunStatus;
	/** "root" hides child runs, which belong to their parent's run tree. */
	parent?: "root";
	limit?: number;
};

export async function fetchRuns(query: RunQuery = {}): Promise<RunSummary[]> {
	const params = new URLSearchParams();
	if (query.agentId) params.set("agentId", query.agentId);
	if (query.repoSlug) params.set("repoSlug", query.repoSlug);
	if (query.status) params.set("status", query.status);
	if (query.parent) params.set("parent", query.parent);
	params.set("limit", String(query.limit ?? 50));

	const body = await getJson<{ runs: RunSummary[] }>(`/api/runs?${params.toString()}`);
	return body?.runs ?? [];
}

export async function fetchRun(runId: string): Promise<RunDetail | undefined> {
	const body = await getJson<{ run: RunDetail }>(`/api/runs/${encodeURIComponent(runId)}`);
	return body?.run;
}
