/**
 * Purpose: Next configuration for Arnold's web tier (App Router).
 *
 * Two things here are load-bearing:
 *   - `@arnold/core` ships TypeScript sources, so it must be transpiled by the
 *     app rather than consumed as a built package.
 *   - Prisma and the Claude Agent SDK must stay external to the server bundle.
 *     Both load native/dynamic files at runtime and break when bundled.
 *
 * There is deliberately no `experimental` block: route handlers stream
 * `ReadableStream` responses natively in Next 16, so SSE needs no flags.
 */

/** @type {import("next").NextConfig} */
const nextConfig = {
	transpilePackages: ["@arnold/core"],
	serverExternalPackages: ["@prisma/client", "@anthropic-ai/claude-agent-sdk"],
};

export default nextConfig;
